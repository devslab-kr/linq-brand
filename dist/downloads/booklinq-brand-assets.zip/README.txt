BookLinq official brand assets
Canonical guidance: https://devslab.kr/brand/products
